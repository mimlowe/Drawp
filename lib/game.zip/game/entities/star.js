ig.module(
	'game.entities.star'
)
.requires(
	'impact.entity'
)
.defines(function(){
var finishX = 480;
var finishY = 10;
var increment;
var count = 0;
EntityStar = ig.Entity.extend({
	size: {x: 32, y: 32},
    isTaken : false,
    xstart: 0, ystart: 0,
	type: ig.Entity.TYPE.A,
	checkAgainst: ig.Entity.TYPE.B,
	collides: ig.Entity.COLLIDES.FIXED,
	
	animSheet: new ig.AnimationSheet( 'media/star.png', 32, 32 ),

	init: function( x, y, settings ) {
		this.addAnim( 'idle', 1, [0] );
		this.timer = new ig.Timer(0.5);
		this.parent( x, y, settings );
		this.xstart = this.pos.x;
		this.ystart = this.pos.y;
	},
	
	check: function (other) {
		if (other instanceof EntityCrate && this.isTaken == false) {
		ig.global.score += 1;
			this.pos.x = finishX;
			this.pos.y = finishY;
			finishX += 32;
			this.isTaken = true;
		}
		
	},
	
	update: function(){
		if( ig.input.pressed('reload')){
			this.isTaken = false;
			this.pos.x = this.xstart;
			this.pos.y = this.ystart;
			finishX = 480;
		}else if(ig.input.pressed('restart')){
			finishX = 480;
		}
	}
	
});


});